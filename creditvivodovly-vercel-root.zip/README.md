# creditvivodovly

Standalone Credit Vivo website build. This is a **separate new project** and is **not integrated** into any existing website, dashboard, payment system, credit-pull system, CRM, Supabase project, or backend.

## Public brand

The public-facing site still says **Credit Vivo**. The project/package/folder name is **creditvivodovly** so you can create a separate GitHub repo and separate Vercel project with that name.

Using a competitor name publicly can create trademark/confusion risk, so the customer-facing brand copy remains Credit Vivo.

## What is included

- Next.js App Router website
- Home page: `/`
- Free review intake page: `/start`
- Customer dashboard preview: `/dashboard`
- Disclosures / compliance reminder page: `/legal`
- Lead intake API route: `/api/lead`
- SEO metadata, sitemap, robots.txt, favicon, logo SVG
- Mobile responsive layout
- Original green/purple fintech design
- No copied competitor images, text, screenshots, or assets

## Important launch status

This build is ready for design review and Vercel deployment as a standalone project.

Before accepting payments or collecting credit reports, connect only after legal/security review:

1. Secure document upload/storage
2. Written customer agreement and cancellation flow
3. Payment processor setup reviewed for CROA/state compliance
4. Privacy policy, terms, data-retention policy, and security procedures
5. Attorney access partner terms and eligibility rules

The public form intentionally does **not** ask for SSN, full account numbers, or credit reports.

## Non-technical Vercel deployment

Create a new Vercel project named:

```text
creditvivodovly
```

Use these settings:

```text
Framework Preset: Next.js
Root Directory: ./
Install Command: npm install
Build Command: npm run build
Output Directory: default / blank
```

Your repo root should contain `app/`, `components/`, `public/`, and `package.json` directly at the top level.

## Lead form setup

The form works in demo mode by default. To send leads into Zapier, Make, HubSpot, Google Sheets, or another CRM, add this environment variable in Vercel:

```bash
LEAD_WEBHOOK_URL=https://your-webhook-url-here
```

Also set:

```bash
NEXT_PUBLIC_SITE_URL=https://creditvivo.com
```

## Local development

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

## Build test

```bash
npm run build
npm run lint
```

## Brand copy used

- AI Credit Boost + Attorney Access
- Find errors. Build disputes. Track progress.
- Better credit can open better doors.
- You take control. We clear the path.
- Results are not guaranteed.

## Compliance note

This is not legal advice. Credit repair advertising, payment timing, contracts, and cancellation rights should be reviewed by qualified counsel before launch.
