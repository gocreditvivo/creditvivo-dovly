# Project status: creditvivodovly

Status: standalone build package.

This project is intentionally separate. It is not connected to:

- existing Credit Vivo Vercel projects
- existing GitHub repos
- Supabase
- Stripe/payment processing
- credit-pull APIs
- document upload/storage
- CRM/webhook unless `LEAD_WEBHOOK_URL` is added later

Deployment target: create a new GitHub repo and Vercel project named `creditvivodovly`.
