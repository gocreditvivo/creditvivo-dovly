'use client';

import { FormEvent, useState } from 'react';

type LeadState = 'idle' | 'sending' | 'success' | 'error';

export function LeadForm() {
  const [state, setState] = useState<LeadState>('idle');
  const [message, setMessage] = useState('');

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setState('sending');
    setMessage('');

    const form = event.currentTarget;
    const data = new FormData(form);

    const payload = {
      fullName: String(data.get('fullName') || ''),
      email: String(data.get('email') || ''),
      phone: String(data.get('phone') || ''),
      goal: String(data.get('goal') || ''),
      scoreRange: String(data.get('scoreRange') || ''),
      timeline: String(data.get('timeline') || ''),
      notes: String(data.get('notes') || ''),
      website: String(data.get('website') || '')
    };

    try {
      const response = await fetch('/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        throw new Error('Lead request failed');
      }

      form.reset();
      setState('success');
      setMessage('Request received. Credit Vivo will contact you about the next step.');
    } catch {
      setState('error');
      setMessage('Something went wrong. Please email gocreditvivo@gmail.com to start your review.');
    }
  }

  return (
    <form className="leadForm" onSubmit={onSubmit}>
      <input className="hiddenField" name="website" tabIndex={-1} autoComplete="off" aria-hidden="true" />
      <div className="formRow two">
        <label>
          Full name
          <input name="fullName" type="text" placeholder="Your name" required />
        </label>
        <label>
          Email
          <input name="email" type="email" placeholder="you@email.com" required />
        </label>
      </div>
      <div className="formRow two">
        <label>
          Phone
          <input name="phone" type="tel" placeholder="Optional" />
        </label>
        <label>
          Current score range
          <select name="scoreRange" defaultValue="">
            <option value="" disabled>Select range</option>
            <option>Below 580</option>
            <option>580–669</option>
            <option>670–739</option>
            <option>740+</option>
            <option>I am not sure</option>
          </select>
        </label>
      </div>
      <label>
        Main credit goal
        <select name="goal" defaultValue="" required>
          <option value="" disabled>Select goal</option>
          <option>Car loan</option>
          <option>Mortgage</option>
          <option>Apartment rental</option>
          <option>Credit cards</option>
          <option>Insurance</option>
          <option>Business funding</option>
          <option>General score improvement</option>
        </select>
      </label>
      <label>
        Timeline
        <select name="timeline" defaultValue="">
          <option value="" disabled>When do you need progress?</option>
          <option>ASAP</option>
          <option>30–60 days</option>
          <option>60–90 days</option>
          <option>3+ months</option>
        </select>
      </label>
      <label>
        What do you want us to review?
        <textarea name="notes" rows={5} placeholder="Example: collections, charge-offs, late payments, personal information, duplicate accounts..." />
      </label>
      <div className="formNotice">
        Do not enter Social Security numbers, full account numbers, or sensitive documents here. Secure credit-report upload should be connected before collecting real reports.
      </div>
      <button className="btn primary" type="submit" disabled={state === 'sending'}>
        {state === 'sending' ? 'Sending...' : 'Start free review'}
      </button>
      {message && <p className={`formMessage ${state}`}>{message}</p>}
    </form>
  );
}
