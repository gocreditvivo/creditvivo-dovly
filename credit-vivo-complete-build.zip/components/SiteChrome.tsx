export function CreditVivoLogo() {
  return (
    <a href="/" className="brand" aria-label="Credit Vivo home">
      <span className="brandMark" aria-hidden="true">
        <span className="brandC">C</span>
        <span className="brandV">V</span>
      </span>
      <span className="brandText">Credit Vivo</span>
    </a>
  );
}

export function SiteNav() {
  return (
    <nav className="nav">
      <div className="navInner">
        <CreditVivoLogo />
        <div className="navLinks" aria-label="Primary navigation">
          <a href="/#how">How it works</a>
          <a href="/#features">Features</a>
          <a href="/dashboard">Dashboard</a>
          <a href="/#pricing">Pricing</a>
          <a href="/legal">Disclosures</a>
        </div>
        <a className="navCta" href="/start">Start free</a>
      </div>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="footer">
      <div className="container footerGrid">
        <div>
          <CreditVivoLogo />
          <p>AI Credit Boost + Attorney Access for consumers who want a clearer credit action plan.</p>
        </div>
        <div>
          <h4>Important disclosures</h4>
          <p>
            Results are not guaranteed. Credit Vivo does not remove accurate, timely, and verifiable information. Consumers may dispute inaccurate credit report information directly with credit bureaus at no cost. Attorney access is not a guarantee of legal representation, litigation, or outcome and may depend on eligibility and partner availability.
          </p>
        </div>
        <div>
          <h4>Contact</h4>
          <p><a href="mailto:gocreditvivo@gmail.com">gocreditvivo@gmail.com</a></p>
          <p><a href="/legal">Disclosures</a></p>
        </div>
      </div>
    </footer>
  );
}
