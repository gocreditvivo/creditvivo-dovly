# Credit Vivo Website

Production-ready starter website for **Credit Vivo** with original design, original copy, and no copied competitor images, text, or assets.

## What is included

- Next.js App Router website
- Home page
- Free review intake page: `/start`
- Customer dashboard preview: `/dashboard`
- Disclosures / compliance reminder page: `/legal`
- Lead intake API route: `/api/lead`
- SEO metadata, sitemap, robots.txt, favicon, logo SVG
- Mobile responsive layout
- Original green/purple fintech look inspired by modern credit apps, not copied from Dovly

## Important launch status

This build is ready for design review and Vercel deployment.

Before accepting payments or collecting credit reports, connect:

1. Secure document upload/storage
2. Written customer agreement and cancellation flow
3. Payment processor setup reviewed for CROA/state compliance
4. Privacy policy, terms, data-retention policy, and security procedures
5. Attorney access partner terms and eligibility rules

The public form intentionally does **not** ask for SSN, full account numbers, or credit reports.

## Non-technical deployment steps for Vercel

1. Go to https://vercel.com
2. Create or open your Vercel account
3. Click **Add New Project**
4. Upload/import this project folder or connect it through GitHub
5. Vercel should detect **Next.js** automatically
6. Click **Deploy**
7. After deployment, add your domain `creditvivo.com` in Vercel → Project → Settings → Domains

## Lead form setup

The form works in demo mode by default. To send leads into Zapier, Make, HubSpot, Google Sheets, or another CRM, add this environment variable in Vercel:

```bash
LEAD_WEBHOOK_URL=https://your-webhook-url-here
```

Also set:

```bash
NEXT_PUBLIC_SITE_URL=https://creditvivo.com
```

## Local development

```bash
npm install
npm run dev
```

Open:

```text
http://localhost:3000
```

## Build test

```bash
npm run build
npm run lint
```

Both were run successfully in the build environment.

## Brand copy used

- AI Credit Boost + Attorney Access
- Find errors. Build disputes. Track progress.
- Better credit can open better doors.
- You take control. We clear the path.
- Results are not guaranteed.

## Compliance note

This is not legal advice. Credit repair advertising, payment timing, contracts, and cancellation rights should be reviewed by qualified counsel before launch.
