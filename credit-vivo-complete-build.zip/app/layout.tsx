import type { Metadata } from 'next';
import type { ReactNode } from 'react';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://creditvivo.com'),
  title: {
    default: 'Credit Vivo | AI Credit Boost + Attorney Access',
    template: '%s | Credit Vivo'
  },
  description:
    'Credit Vivo helps consumers find credit report errors, build disputes, track progress, and access attorney support for eligible unresolved issues.',
  applicationName: 'Credit Vivo',
  keywords: [
    'Credit Vivo',
    'AI credit review',
    'credit report errors',
    'dispute tracking',
    'attorney access',
    'credit score goals'
  ],
  icons: {
    icon: '/favicon.svg'
  },
  openGraph: {
    title: 'Credit Vivo | AI Credit Boost + Attorney Access',
    description: 'Find errors. Build disputes. Track progress.',
    url: '/',
    siteName: 'Credit Vivo',
    type: 'website'
  }
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
