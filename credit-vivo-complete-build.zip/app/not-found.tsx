import { Footer, SiteNav } from '@/components/SiteChrome';

export default function NotFound() {
  return (
    <main>
      <SiteNav />
      <section className="pageHero sectionPad">
        <div className="container centerHead narrow legalHead">
          <p className="pill">404</p>
          <h1>Page not found.</h1>
          <p className="heroText">The page you are looking for does not exist. Start with the Credit Vivo home page or free review intake.</p>
          <a className="btn primary" href="/">Go home</a>
        </div>
      </section>
      <Footer />
    </main>
  );
}
