import { Footer, SiteNav } from '@/components/SiteChrome';

const flow = ['Upload Report', 'AI Findings', 'Negative Accounts', 'Start Dispute', 'Track Progress'];

const accounts = [
  { name: 'Collection account', issue: 'Possible duplicate / bureau mismatch', status: 'Review' },
  { name: 'Charge-off account', issue: 'Balance and date inconsistencies', status: 'Prepare' },
  { name: 'Late payment', issue: 'Status wording differs by bureau', status: 'Track' }
];

const findings = [
  { label: 'Possible identity issues', value: '2', detail: 'Names / address variations' },
  { label: 'Negative accounts', value: '4', detail: 'Collections, charge-offs, late payments' },
  { label: 'Bureau mismatches', value: '6', detail: 'Dates, balances, statuses' },
  { label: 'Next review window', value: '30', detail: 'Days after dispute mailing' }
];

export const metadata = {
  title: 'Dashboard Preview | Credit Vivo',
  description: 'Preview the Credit Vivo customer dashboard for AI findings, negative accounts, dispute tracking, and attorney access routing.'
};

export default function DashboardPage() {
  return (
    <main>
      <SiteNav />
      <section className="pageHero sectionPad">
        <div className="container pageHeroGrid">
          <div>
            <p className="pill">Customer dashboard preview</p>
            <h1>Clean customer flow. Powerful credit workflow.</h1>
            <p className="heroLead">Upload Report → AI Findings → Negative Accounts → Start Dispute → Track Progress.</p>
            <p className="heroText">
              This page is a safe front-end preview. It shows how customers would see the process without exposing the deeper forensic engine.
            </p>
            <a className="btn primary" href="/start">Start free review</a>
          </div>
          <div className="appShell">
            <div className="appSidebar">
              <b>Credit Vivo</b>
              {flow.map((item, index) => <span className={index === 1 ? 'active' : ''} key={item}>{item}</span>)}
            </div>
            <div className="appMain">
              <div className="appTop"><b>AI Findings</b><span>Demo data</span></div>
              <div className="findingGrid">
                {findings.map((finding) => (
                  <div className="findingTile" key={finding.label}>
                    <strong>{finding.value}</strong>
                    <span>{finding.label}</span>
                    <small>{finding.detail}</small>
                  </div>
                ))}
              </div>
              <div className="accountList">
                {accounts.map((account) => (
                  <div className="accountRow" key={account.name}>
                    <div>
                      <b>{account.name}</b>
                      <span>{account.issue}</span>
                    </div>
                    <em>{account.status}</em>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="sectionPad greenSoft">
        <div className="container centerHead narrow">
          <p className="eyebrow">What customers see</p>
          <h2>Simple, not scary.</h2>
          <p>The front-end avoids showing Metro 2 jargon first. The system can still store the deeper logic behind each finding for internal review and attorney escalation.</p>
        </div>
        <div className="container cardsGrid">
          <article className="featureCard">
            <div className="miniIllustration mini1" />
            <p className="eyebrow">AI Review</p>
            <h3>Plain-English findings</h3>
            <p>Customers see what may be wrong and why it matters to their credit goal.</p>
          </article>
          <article className="featureCard">
            <div className="miniIllustration mini2" />
            <p className="eyebrow">Disputes</p>
            <h3>Focused packages</h3>
            <p>Letters, evidence, dates, and supporting notes stay organized in one place.</p>
          </article>
          <article className="featureCard">
            <div className="miniIllustration mini3" />
            <p className="eyebrow">Escalation</p>
            <h3>Attorney access path</h3>
            <p>Eligible unresolved issues can be routed with a clean timeline and evidence file.</p>
          </article>
        </div>
      </section>
      <Footer />
    </main>
  );
}
