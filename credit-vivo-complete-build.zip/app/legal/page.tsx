import { Footer, SiteNav } from '@/components/SiteChrome';

const disclosures = [
  {
    title: 'No guaranteed results',
    copy: 'Credit Vivo cannot guarantee a credit score increase, account deletion, loan approval, or specific outcome. Results vary based on the credit report, creditor responses, bureau investigations, payment behavior, debt balances, and other factors.'
  },
  {
    title: 'Accurate information',
    copy: 'Credit Vivo does not claim it can remove accurate, timely, and verifiable information from a credit report. The service focuses on helping consumers identify and dispute information that may be inaccurate, incomplete, unverifiable, outdated, duplicate, or questionable.'
  },
  {
    title: 'Consumer rights',
    copy: 'Consumers may dispute inaccurate information directly with credit bureaus and furnishers without paying Credit Vivo or any credit repair organization. Credit Vivo is a technology and support service for customers who want help organizing the process.'
  },
  {
    title: 'Attorney access',
    copy: 'Attorney access is not a guarantee of legal representation, litigation, settlement, or outcome. Eligibility, availability, state coverage, and partner terms may apply.'
  },
  {
    title: 'Sensitive data',
    copy: 'The public website should not collect Social Security numbers, full account numbers, or credit reports until a secure upload, written contract, privacy policy, retention policy, and compliance workflow are active.'
  },
  {
    title: 'Payment setup',
    copy: 'Before collecting payment, Credit Vivo should complete legal review for CROA, state credit services organization rules, cancellation rights, written contracts, payment timing, telemarketing rules, privacy, GLBA-style safeguards, and advertising claims.'
  }
];

export const metadata = {
  title: 'Disclosures | Credit Vivo',
  description: 'Important Credit Vivo disclosures, consumer rights language, attorney access notes, and launch compliance reminders.'
};

export default function LegalPage() {
  return (
    <main>
      <SiteNav />
      <section className="pageHero sectionPad">
        <div className="container centerHead narrow legalHead">
          <p className="pill">Important disclosures</p>
          <h1>Credit repair must be sold carefully.</h1>
          <p className="heroLead">Strong marketing. No fake promises.</p>
          <p className="heroText">
            These website disclosures are startup placeholders. They should be reviewed by qualified compliance counsel before public launch, advertising, payment collection, or credit-report upload.
          </p>
        </div>
      </section>

      <section className="sectionPad mint">
        <div className="container disclosureGrid">
          {disclosures.map((item) => (
            <article className="featureCard" key={item.title}>
              <p className="eyebrow">Disclosure</p>
              <h3>{item.title}</h3>
              <p>{item.copy}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="finalCta sectionPad">
        <div className="container finalBox">
          <div>
            <p className="pill">Launch checklist</p>
            <h2>Connect legal, payment, and secure upload last.</h2>
            <p>Keep the landing page live for leads first. Add payment and credit-report upload only after compliance review.</p>
          </div>
          <a className="btn primary" href="/start">Back to intake</a>
        </div>
      </section>
      <Footer />
    </main>
  );
}
