const goals = [
  'Better car loan options',
  'Mortgage readiness',
  'Apartment approvals',
  'Lower insurance pressure',
  'Job screening confidence',
  'Credit card opportunities'
];

const steps = [
  {
    number: '01',
    title: 'Start your free review',
    copy: 'Tell us your credit goal and upload a report later through a secure intake flow. No credit pull is required for the website demo.'
  },
  {
    number: '02',
    title: 'See AI credit findings',
    copy: 'Credit Vivo organizes possible report errors, negative accounts, date issues, balance mismatches, and personal-info problems in plain English.'
  },
  {
    number: '03',
    title: 'Build, send, and track',
    copy: 'Create focused dispute packages, track 30–45 day windows, store evidence, and prepare eligible unresolved issues for attorney access.'
  }
];

const features = [
  {
    eyebrow: 'AI Credit Boost',
    title: 'Find errors faster.',
    copy: 'Scan negative accounts, identity data, dates, balances, creditor names, account status, and bureau-to-bureau reporting differences.',
    cta: 'View dashboard preview',
    href: '/dashboard'
  },
  {
    eyebrow: 'Attorney Access',
    title: 'Backup when it matters.',
    copy: 'Organize eligible unresolved credit-reporting issues with dispute history, evidence, and timeline notes for legal review.',
    cta: 'See disclosure',
    href: '/legal'
  },
  {
    eyebrow: 'Score Goals',
    title: 'Know what you’re aiming for.',
    copy: 'Set a target score range and focus on report factors that may be holding you back. No fake promises. Just a clearer plan.',
    cta: 'Start review',
    href: '/start'
  }
];

const plans = [
  {
    name: 'Free Scan',
    price: '$0',
    label: 'Start here',
    items: ['Credit goal intake', 'AI issue preview concept', 'Score goal education', 'Basic action checklist'],
    featured: false
  },
  {
    name: 'Premium',
    price: '$49/mo',
    label: 'Best value',
    items: ['Full AI credit review', 'Dispute package builder', '3-bureau tracking', 'Monthly action plan', 'Evidence vault'],
    featured: true
  },
  {
    name: 'Premium + Attorney',
    price: '$79/mo',
    label: 'Extra support',
    items: ['Everything in Premium', 'Attorney access path', 'Escalation review', 'Complaint package prep', 'Priority support'],
    featured: false
  }
];

const faqs = [
  {
    q: 'Can Credit Vivo guarantee a score increase?',
    a: 'No. Credit results depend on your report, creditor responses, bureau investigations, payment behavior, debt balances, and other factors.'
  },
  {
    q: 'Can accurate negative information be removed?',
    a: 'Accurate, timely, and verifiable negative information generally cannot be removed just because it hurts a score. Credit Vivo focuses on inaccurate, incomplete, unverifiable, outdated, duplicate, or questionable reporting.'
  },
  {
    q: 'Do I need an attorney for every dispute?',
    a: 'No. Most customers start with AI review and dispute tracking. Attorney access is for eligible unresolved or serious credit-reporting issues where legal review may be helpful.'
  },
  {
    q: 'Can I dispute credit report errors myself for free?',
    a: 'Yes. Consumers can dispute inaccurate information directly with credit bureaus and furnishers at no cost. Credit Vivo is a paid technology and support service for people who want help organizing the process.'
  }
];

function CreditVivoLogo() {
  return (
    <a href="/" className="brand" aria-label="Credit Vivo home">
      <span className="brandMark" aria-hidden="true">
        <span className="brandC">C</span>
        <span className="brandV">V</span>
      </span>
      <span className="brandText">Credit Vivo</span>
    </a>
  );
}

function PhoneMockup() {
  return (
    <div className="phoneWrap" aria-label="Credit Vivo app dashboard preview">
      <div className="phone">
        <div className="phoneTop" />
        <div className="phoneHeader">
          <span>Credit Vivo</span>
          <b>AI Review</b>
        </div>
        <div className="scoreCircle">
          <span>Goal</span>
          <strong>670+</strong>
          <small>Good credit range</small>
        </div>
        <div className="finding good">
          <span className="dot" />
          <div>
            <b>3 possible report errors</b>
            <small>Dates, balances, account status</small>
          </div>
        </div>
        <div className="finding warn">
          <span className="dot" />
          <div>
            <b>2 negative accounts</b>
            <small>Ready for review</small>
          </div>
        </div>
        <div className="finding neutral">
          <span className="dot" />
          <div>
            <b>Dispute tracker</b>
            <small>Next update in 14 days</small>
          </div>
        </div>
        <a className="phoneBtn" href="/start">Start dispute</a>
      </div>
      <div className="floatCard cardOne">
        <b>+ Focus</b>
        <span>Payment history</span>
      </div>
      <div className="floatCard cardTwo">
        <b>AI</b>
        <span>Find errors</span>
      </div>
    </div>
  );
}

function AbstractCreditCard() {
  return (
    <div className="abstractCard" aria-hidden="true">
      <div className="chip" />
      <div className="cardLine long" />
      <div className="cardLine" />
      <div className="cardDots"><span /><span /></div>
    </div>
  );
}

export default function Home() {
  return (
    <main id="top">
      <nav className="nav">
        <div className="navInner">
          <CreditVivoLogo />
          <div className="navLinks" aria-label="Primary navigation">
            <a href="#how">How it works</a>
            <a href="#features">Features</a>
            <a href="/dashboard">Dashboard</a>
            <a href="#pricing">Pricing</a>
            <a href="/legal">Disclosures</a>
          </div>
          <a className="navCta" href="/start">Start free</a>
        </div>
      </nav>

      <section className="hero sectionPad">
        <div className="heroGrid container">
          <div className="heroCopy">
            <p className="pill">AI Credit Boost + Attorney Access</p>
            <h1>Build toward your next credit goal.</h1>
            <p className="heroLead">Find errors. Build disputes. Track progress.</p>
            <p className="heroText">
              Credit Vivo helps consumers review credit reports, focus on score-impacting issues, and organize a smarter path toward better credit opportunities.
            </p>
            <div className="heroActions">
              <a className="btn primary" href="/start">Start free review</a>
              <a className="btn secondary" href="/dashboard">Preview dashboard</a>
            </div>
            <div className="trustMini">
              <span>No score guarantees</span>
              <span>Consumer-friendly</span>
              <span>Built for tracking</span>
            </div>
          </div>
          <div className="heroArt">
            <AbstractCreditCard />
            <div className="orb orbOne" />
            <div className="orb orbTwo" />
            <PhoneMockup />
          </div>
        </div>
      </section>

      <section className="logoStrip">
        <div className="container logoRow" aria-label="Credit Vivo service categories">
          <span>3-bureau review</span>
          <span>Dispute builder</span>
          <span>Score goals</span>
          <span>Attorney access</span>
          <span>Progress tracking</span>
        </div>
      </section>

      <section className="split sectionPad mint" id="features">
        <div className="container splitGrid">
          <div className="photoCard lifestyleOne">
            <span className="photoBadge">AI</span>
            <div className="photoText">Credit clarity on your phone.</div>
          </div>
          <div className="sectionCopy">
            <p className="eyebrow">Better credit can open better doors</p>
            <h2>Better car loans, homes, rentals, jobs, and insurance.</h2>
            <p>
              Your credit can affect everyday opportunities. Credit Vivo turns a confusing report into a simple action plan focused on what may be holding your score back.
            </p>
            <div className="goalGrid">
              {goals.map((goal) => (
                <div className="goal" key={goal}>{goal}</div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="sectionPad" id="how">
        <div className="container centerHead">
          <p className="eyebrow">How it works</p>
          <h2>Simple steps. Smarter disputes.</h2>
        </div>
        <div className="container stepsGrid">
          {steps.map((step) => (
            <article className="stepCard" key={step.number}>
              <span>{step.number}</span>
              <h3>{step.title}</h3>
              <p>{step.copy}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="featureBlocks sectionPad greenSoft">
        <div className="container cardsGrid">
          {features.map((item, index) => (
            <article className="featureCard" key={item.title}>
              <div className={`miniIllustration mini${index + 1}`} />
              <p className="eyebrow">{item.eyebrow}</p>
              <h3>{item.title}</h3>
              <p>{item.copy}</p>
              <a href={item.href}>{item.cta} →</a>
            </article>
          ))}
        </div>
      </section>

      <section className="scoreBand sectionPad">
        <div className="container scoreGrid">
          <div>
            <p className="eyebrow">Your credit, your plan</p>
            <h2>A clear goal gives customers something to fight for.</h2>
            <p>
              We show customers score ranges, key report factors, and next steps without promising a specific point increase.
            </p>
          </div>
          <div className="scoreMeter">
            <div className="meterTop">
              <span>Target range</span>
              <strong>670+</strong>
            </div>
            <div className="meterBar"><span /></div>
            <div className="meterLabels"><span>Fair</span><span>Good</span><span>Very good</span></div>
            <p>Good FICO® Score range: 670–739. Lenders may use different scores and criteria.</p>
          </div>
        </div>
      </section>

      <section className="sectionPad dashboardTeaser">
        <div className="container splitGrid reverse">
          <div className="sectionCopy">
            <p className="eyebrow">Customer dashboard</p>
            <h2>Clean front-end. Strong back-end workflow.</h2>
            <p>
              The dashboard preview shows the customer-facing flow: Upload Report → AI Findings → Negative Accounts → Start Dispute → Track Progress.
            </p>
            <a className="btn primary" href="/dashboard">Open dashboard preview</a>
          </div>
          <div className="dashboardCard" aria-label="Dashboard preview">
            <div className="dashTop"><b>AI Findings</b><span>Demo</span></div>
            <div className="dashItem"><strong>Identity data</strong><span>2 items to review</span></div>
            <div className="dashItem"><strong>Negative accounts</strong><span>4 accounts found</span></div>
            <div className="dashItem"><strong>Possible mismatches</strong><span>Dates, balances, status</span></div>
            <div className="dashProgress"><span /></div>
          </div>
        </div>
      </section>

      <section className="sectionPad" id="pricing">
        <div className="container centerHead narrow">
          <p className="eyebrow">Launch pricing</p>
          <h2>Start free. Upgrade when you want help.</h2>
          <p>Pricing below is placeholder launch copy and should be reviewed by compliance counsel before accepting payments.</p>
        </div>
        <div className="container pricingGrid">
          {plans.map((plan) => (
            <article className={`priceCard ${plan.featured ? 'featured' : ''}`} key={plan.name}>
              <div className="priceHead">
                <p>{plan.label}</p>
                <h3>{plan.name}</h3>
                <strong>{plan.price}</strong>
              </div>
              <ul>
                {plan.items.map((item) => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
              <a href="/start" className={plan.featured ? 'btn primary' : 'btn secondary'}>Choose plan</a>
            </article>
          ))}
        </div>
      </section>

      <section className="stats sectionPad greenStrong">
        <div className="container statsGrid">
          <div>
            <strong>3</strong>
            <span>Bureau review</span>
          </div>
          <div>
            <strong>24/7</strong>
            <span>Dashboard access</span>
          </div>
          <div>
            <strong>30–45</strong>
            <span>Day tracking windows</span>
          </div>
          <div>
            <strong>0</strong>
            <span>Score guarantees</span>
          </div>
        </div>
      </section>

      <section className="sectionPad customerGoals">
        <div className="container splitGrid reverse">
          <div className="sectionCopy">
            <p className="eyebrow">Made for real-life goals</p>
            <h2>Not just reports. Better decisions.</h2>
            <p>
              Customers do not need to understand Metro 2, FCRA, or dispute codes. They need to know what looks wrong, what to do next, and where the process stands.
            </p>
            <a className="btn primary" href="/start">Get my AI review</a>
          </div>
          <div className="photoCard lifestyleTwo">
            <span className="photoBadge">CV</span>
            <div className="photoText">Simple dashboard. Stronger documentation.</div>
          </div>
        </div>
      </section>

      <section className="sectionPad faqSection" id="faq">
        <div className="container centerHead narrow">
          <p className="eyebrow">FAQs</p>
          <h2>Clear answers before customers sign up.</h2>
        </div>
        <div className="container faqList">
          {faqs.map((faq) => (
            <details key={faq.q}>
              <summary>{faq.q}</summary>
              <p>{faq.a}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="finalCta sectionPad" id="start">
        <div className="container finalBox">
          <div>
            <p className="pill">You take control. We clear the path.</p>
            <h2>Ready to see what may be hurting your credit?</h2>
            <p>Start with the intake page, get AI findings, and decide the next move.</p>
          </div>
          <a className="btn primary" href="/start">Start with Credit Vivo</a>
        </div>
      </section>

      <footer className="footer">
        <div className="container footerGrid">
          <div>
            <CreditVivoLogo />
            <p>AI Credit Boost + Attorney Access for consumers who want a clearer credit action plan.</p>
          </div>
          <div>
            <h4>Important disclosures</h4>
            <p>
              Results are not guaranteed. Credit Vivo does not remove accurate, timely, and verifiable information. Consumers may dispute inaccurate credit report information directly with credit bureaus at no cost. Attorney access is not a guarantee of legal representation, litigation, or outcome and may depend on eligibility and partner availability.
            </p>
          </div>
          <div>
            <h4>Contact</h4>
            <p><a href="mailto:gocreditvivo@gmail.com">gocreditvivo@gmail.com</a></p>
            <p><a href="/legal">Disclosures</a></p>
          </div>
        </div>
      </footer>
    </main>
  );
}
