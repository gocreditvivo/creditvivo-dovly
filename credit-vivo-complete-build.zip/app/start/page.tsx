import { LeadForm } from '@/components/LeadForm';
import { Footer, SiteNav } from '@/components/SiteChrome';

const checklist = [
  'No hard credit pull from this website',
  'No Social Security number in the form',
  'No score guarantee language',
  'Secure report upload should be connected before launch'
];

const nextSteps = [
  'We review your credit goal and reported issues.',
  'You receive a simple next-step checklist.',
  'Paid plan and secure upload are offered only after compliance setup.',
  'Eligible unresolved issues may be organized for attorney access.'
];

export const metadata = {
  title: 'Start Free Review | Credit Vivo',
  description: 'Start a free Credit Vivo review request for AI credit findings and attorney access options.'
};

export default function StartPage() {
  return (
    <main>
      <SiteNav />
      <section className="pageHero sectionPad">
        <div className="container pageHeroGrid">
          <div>
            <p className="pill">Free Credit Vivo intake</p>
            <h1>Start with your credit goal.</h1>
            <p className="heroLead">Tell us what you want to fix, build, or qualify for.</p>
            <p className="heroText">
              This is the lead intake page for the production website. It is designed to collect safe contact information first, then move customers into a secure upload and onboarding flow after compliance review.
            </p>
            <div className="miniList">
              {checklist.map((item) => <span key={item}>{item}</span>)}
            </div>
          </div>
          <LeadForm />
        </div>
      </section>

      <section className="sectionPad mint">
        <div className="container centerHead narrow">
          <p className="eyebrow">What happens next</p>
          <h2>Simple intake. Safer launch.</h2>
          <p>Credit repair onboarding must be careful. This build starts with a compliant lead flow instead of collecting sensitive documents too early.</p>
        </div>
        <div className="container stepsGrid">
          {nextSteps.map((step, index) => (
            <article className="stepCard" key={step}>
              <span>{String(index + 1).padStart(2, '0')}</span>
              <h3>{step}</h3>
              <p>Customers stay informed without being promised a guaranteed point increase or guaranteed removal.</p>
            </article>
          ))}
        </div>
      </section>

      <section className="finalCta sectionPad">
        <div className="container finalBox">
          <div>
            <p className="pill">Need help now?</p>
            <h2>Email Credit Vivo directly.</h2>
            <p>Use this while payment, secure uploads, and attorney routing are being connected.</p>
          </div>
          <a className="btn primary" href="mailto:gocreditvivo@gmail.com?subject=Start%20Credit%20Vivo%20Review">Email us</a>
        </div>
      </section>
      <Footer />
    </main>
  );
}
