import { NextRequest, NextResponse } from 'next/server';

const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    if (body.website) {
      return NextResponse.json({ ok: true, spamFiltered: true });
    }

    const fullName = String(body.fullName || '').trim();
    const email = String(body.email || '').trim();
    const phone = String(body.phone || '').trim();
    const goal = String(body.goal || '').trim();
    const scoreRange = String(body.scoreRange || '').trim();
    const timeline = String(body.timeline || '').trim();
    const notes = String(body.notes || '').trim();

    if (!fullName || !emailPattern.test(email) || !goal) {
      return NextResponse.json({ ok: false, error: 'Missing required fields.' }, { status: 400 });
    }

    const lead = {
      source: 'creditvivo.com',
      fullName,
      email,
      phone,
      goal,
      scoreRange,
      timeline,
      notes,
      submittedAt: new Date().toISOString()
    };

    const webhookUrl = process.env.LEAD_WEBHOOK_URL;

    if (webhookUrl) {
      const webhookResponse = await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(lead)
      });

      if (!webhookResponse.ok) {
        return NextResponse.json({ ok: false, error: 'Lead webhook failed.' }, { status: 502 });
      }
    } else {
      console.log('Credit Vivo lead received. Add LEAD_WEBHOOK_URL to forward this lead:', lead);
    }

    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: false, error: 'Invalid request.' }, { status: 400 });
  }
}
